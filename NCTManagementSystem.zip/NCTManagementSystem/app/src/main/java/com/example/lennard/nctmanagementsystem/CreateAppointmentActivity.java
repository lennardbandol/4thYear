package com.example.lennard.nctmanagementsystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by lennard on 21/08/2017.
 */

public class CreateAppointmentActivity extends AppCompatActivity {

    //Database
    DatabaseHelper myDb;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_appointment_layout);

        //initialize database
        myDb = new DatabaseHelper(this);

        //Spinner
        Spinner day_spinner = (Spinner) findViewById(R.id.spinner_user_type);
        Spinner month_spinner = (Spinner) findViewById(R.id.date_month);
        Spinner year_spinner = (Spinner) findViewById(R.id.date_year);
        Spinner time_spinner = (Spinner) findViewById(R.id.time);

        //Spinner Adapter
        ArrayAdapter<CharSequence> day_adapter = ArrayAdapter.createFromResource(this,
                R.array.days, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> month_adapter = ArrayAdapter.createFromResource(this,
                R.array.months, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> year_adapter = ArrayAdapter.createFromResource(this,
                R.array.year, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> time_adapter = ArrayAdapter.createFromResource(this,
                R.array.time, android.R.layout.simple_spinner_item);

        day_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        month_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        time_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        day_spinner.setAdapter(day_adapter);
        month_spinner.setAdapter(month_adapter);
        year_spinner.setAdapter(year_adapter);
        time_spinner.setAdapter(time_adapter);

        createAppointment();
    }

    private void createAppointment(){

        final EditText et_firstName = (EditText)findViewById(R.id.eT_customer_firstName);
        final EditText et_lastName = (EditText)findViewById(R.id.eT_customer_lastName);
        final EditText et_email = (EditText)findViewById(R.id.eT_customer_email);
        final EditText et_telephone = (EditText)findViewById(R.id.eT_customer_telephone);
        final EditText et_address = (EditText)findViewById(R.id.et_customer_address);

        final Spinner day =(Spinner) findViewById(R.id.spinner_user_type);
        final Spinner month =(Spinner) findViewById(R.id.date_month);
        final Spinner year =(Spinner) findViewById(R.id.date_year);
        final Spinner time =(Spinner) findViewById(R.id.time);

        final TextView next = (TextView)findViewById(R.id.tV_appointment_next);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Variables
                final String firstName = et_firstName.getText().toString();
                final String lastName = et_lastName.getText().toString();
                final String email = et_email.getText().toString();
                final String telephone = et_telephone.getText().toString();
                final String address = et_address.getText().toString();

                final String selected_day = day.getSelectedItem().toString();
                final String selected_month = month.getSelectedItem().toString();
                final String selected_year = year.getSelectedItem().toString();
                final String selected_time = time.getSelectedItem().toString();

                //Error Check
                if(firstName.equals("") || lastName.equals("") || email.equals("") || address.equals("") || telephone.equals("") || selected_day.equals("") || selected_month.equals("") || selected_year.equals("") || selected_time.equals("")){

                    Toast.makeText(getApplicationContext(), "Empty Fields!", Toast.LENGTH_LONG).show();

                }
                else{

                    //dialog to confirm details
                    AlertDialog.Builder builder = new AlertDialog.Builder(CreateAppointmentActivity.this);
                    builder.setTitle("Confirm Details");
                    builder.setMessage("Are all details correct?");

                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                        //if the user confirm details
                        public void onClick(DialogInterface dialog, int which) {

                            //check time chosen
                            int time_check = myDb.checkAppointmentTime(selected_day,selected_month,selected_year,selected_time);

                            if(time_check == 1){
                                Toast.makeText(getApplicationContext(), "Please choose a different time", Toast.LENGTH_LONG).show();
                                dialog.dismiss();
                            }
                            else {

                                //change to vehicle layout
                                setContentView(R.layout.vehicle_detail_layout);

                                TextView book = (TextView) findViewById(R.id.tV_appointment_book);

                                book.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                        final EditText et_plateNumber = (EditText) findViewById(R.id.eT_vehicle_plateNumber);
                                        final EditText et_make = (EditText) findViewById(R.id.eT_vehicle_make);
                                        final EditText et_model = (EditText) findViewById(R.id.eT_vehicle_model);
                                        final EditText et_mileage = (EditText) findViewById(R.id.eT_vehicle_mileage);
                                        final EditText et_color = (EditText) findViewById(R.id.eT_vehicle_color);
                                        final EditText et_car_year = (EditText) findViewById(R.id.eT_vehicle_year);

                                        //Variables
                                        final String plateNumber = et_plateNumber.getText().toString();
                                        final String make = et_make.getText().toString();
                                        final String model = et_model.getText().toString();
                                        final String mileage = et_mileage.getText().toString();
                                        final String color = et_color.getText().toString();
                                        final String year = et_car_year.getText().toString();

                                        if (plateNumber.equals("") || make.equals("") || model.equals("") || mileage.equals("") || color.equals("") || year.equals("")) {
                                            Toast.makeText(getApplicationContext(), "Empty Fields!", Toast.LENGTH_LONG).show();
                                        } else {

                                            AlertDialog.Builder builder = new AlertDialog.Builder(CreateAppointmentActivity.this);
                                            builder.setTitle("Confirm Details");
                                            builder.setMessage("Are all details correct?");

                                            //yes option
                                            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {

                                                    //error check for plate Number
                                                    int result = myDb.checkPlateNumber(plateNumber);

                                                    if (result == 0) {
                                                        //insert appointment bookings
                                                        myDb.addCustomerDetails(firstName, lastName, email, telephone, address, plateNumber);

                                                        //Add to Appointment Table
                                                        myDb.addAppointment(selected_day, selected_month, selected_year, selected_time, plateNumber);

                                                        String testDate = selected_day + " " + selected_month + " " + selected_year;
                                                        //Add Customer Vehicle Details
                                                        myDb.addVehicle(plateNumber, make, model, mileage, color, year,"UNTESTED",testDate);

                                                        Toast.makeText(getApplicationContext(), "Appointment Added", Toast.LENGTH_LONG).show();
                                                        Intent intent = new Intent(CreateAppointmentActivity.this, AdminActivity.class);
                                                        startActivity(intent);
                                                    } else {
                                                        //change to vehicle layout
                                                        Toast.makeText(getApplicationContext(), "Vehicle already have an appointment", Toast.LENGTH_LONG).show();
                                                        Intent intent = new Intent(CreateAppointmentActivity.this, AdminActivity.class);
                                                        startActivity(intent);
                                                    }

                                                }
                                            });

                                            //no option
                                            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    // Do nothing
                                                    dialog.dismiss();
                                                }
                                            });

                                            AlertDialog alert = builder.create();
                                            alert.show();

                                        }
                                    }
                                });
                            }
                        }
                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // Do nothing
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alert = builder.create();
                    alert.show();

                }
            }
        });
    }
}
