package com.example.lennard.nctmanagementsystem;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by lennard on 30/08/2017.
 */

public class ViewResultActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.view_results);

        displayTestedCars();
        search();

    }

    private void search() {
        final EditText searchQuery= (EditText)findViewById(R.id.etSearchTestedCar);
        searchQuery.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String plateNumber = searchQuery.getText().toString();
                searchTestedCar(plateNumber);
            }
        });
    }

    private void searchTestedCar(String plateNumber) {

        if(plateNumber.equals("")){
            displayTestedCars();
        }
        else {
            //display the searched views
            DatabaseHelper myDb = new DatabaseHelper(this);
            Cursor c = myDb.getTestedCarSearchResult(plateNumber);
            //display all appointment sorted by date
            DatabaseHelper db = new DatabaseHelper(this);
            String[] from = new String[]{DatabaseHelper.VEHICLE_PLATE_NUMBER_COL, DatabaseHelper.VEHICLE_MODEL_COL, DatabaseHelper.VEHICLE_MAKE_COL,DatabaseHelper.VEHICLE_MILEAGE_COL,DatabaseHelper.VEHICLE_COLOR_COL,DatabaseHelper.VEHICLE_YEAR_COL};
            int[] to = new int[]{R.id.tV_tested_plate_number, R.id.tV_tested_model, R.id.tV_tested_make,R.id.tV_tested_mileage,R.id.tV_tested_color,R.id.tV_tested_year};
            SimpleCursorAdapter testedAdapter;
            testedAdapter = new SimpleCursorAdapter(this, R.layout.tested_car_list, c, from, to, 0);
            ListView testedList = (ListView) findViewById(R.id.lv_tested_cars);
            testedList.setAdapter(testedAdapter);
            testedList.setTextFilterEnabled(true);

            //DISPLAY TESTED ITEMS DETAILS
            testedList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1,
                                        int position, long arg3) {

                    //Text View of the chosen plate number
                    final TextView tV_clicked_plate_number = arg1.findViewById(R.id.tV_tested_plate_number);
                    //Store the chosen plate number
                    final String tested_plate_number = tV_clicked_plate_number.getText().toString();
                    displayTestedParts(tested_plate_number);

                }
            });
        }
    }

    public void displayTestedCars(){

        DatabaseHelper db = new DatabaseHelper(this);
        Cursor c = db.getAllTestedVehicle();
        String[] from = new String[]{DatabaseHelper.VEHICLE_PLATE_NUMBER_COL, DatabaseHelper.VEHICLE_MODEL_COL, DatabaseHelper.VEHICLE_MAKE_COL,DatabaseHelper.VEHICLE_MILEAGE_COL,DatabaseHelper.VEHICLE_COLOR_COL,DatabaseHelper.VEHICLE_YEAR_COL};
        int[] to = new int[]{R.id.tV_tested_plate_number, R.id.tV_tested_model, R.id.tV_tested_make,R.id.tV_tested_mileage,R.id.tV_tested_color,R.id.tV_tested_year};
        SimpleCursorAdapter testedAdapter;
        testedAdapter = new SimpleCursorAdapter(this, R.layout.tested_car_list, c, from, to, 0);
        ListView testedList = (ListView) findViewById(R.id.lv_tested_cars);
        testedList.setAdapter(testedAdapter);
        testedList.setTextFilterEnabled(true);

        //DISPLAY TESTED CAR DETAILS
        testedList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long arg3) {

                //Text View of the chosen plate number
                final TextView tV_clicked_plate_number = arg1.findViewById(R.id.tV_tested_plate_number);
                //Store the chosen plate number
                final String tested_plate_number = tV_clicked_plate_number.getText().toString();

                displayTestedParts(tested_plate_number);

            }
        });
    }

    public void displayTestedParts(String plateNumber){

        setContentView(R.layout.tested_parts_layout);
        DatabaseHelper db = new DatabaseHelper(this);

        final TextView tV_tested_vehicle_plate_number = (TextView)findViewById(R.id.tV_title_tested_vehicle_plate_number);
        String mechanicName = db.getMechanicName(plateNumber);
        tV_tested_vehicle_plate_number.setText("Vehicle - " + plateNumber + " Tested By - " + mechanicName);

        Cursor c = db.getTestedParts(plateNumber);
        String[] from = new String[]{DatabaseHelper.TEST_PART_NAME_COL, DatabaseHelper.TEST_RESULT_COL, DatabaseHelper.TEST_DETAILS_COL};
        int[] to = new int[]{R.id.tV_tested_part_name, R.id.tV_tested_result,R.id.tV_tested_details};
        SimpleCursorAdapter untestedAdapter;
        untestedAdapter = new SimpleCursorAdapter(this, R.layout.tested_list_parts, c, from, to, 0);
        ListView untestedList = (ListView) findViewById(R.id.lv_tested_parts);
        untestedList.setAdapter(untestedAdapter);
        untestedList.setTextFilterEnabled(true);

        TextView printBtn = (TextView)findViewById(R.id.tV_print_btn);

        printBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ViewResultActivity.this,AdminActivity.class);
                Toast.makeText(getApplicationContext(), "Printed", Toast.LENGTH_LONG).show();
                startActivity(intent);
            }
        });

    }
}