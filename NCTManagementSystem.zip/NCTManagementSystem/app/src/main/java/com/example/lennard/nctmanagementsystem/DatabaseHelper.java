package com.example.lennard.nctmanagementsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by lennardglenn on 11/13/2016.
 */

import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    //database name
    public static final String db_name= "nct.db";
    private static final int DATABASE_VERSION = 1;

    //table names
    public static final String EMPLOYEE_TABLE = "EMPLOYEE";
    public static final String CUSTOMER_TABLE = "CUSTOMER";
    public static final String APPOINTMENT_TABLE = "APPOINTMENT";
    public static final String VEHICLE_TABLE = "VEHICLE";
    public static final String PART_TABLE = "PART";
    public static final String PART_ITEM_TABLE = "PART_ITEM";
    public static final String TEST_TABLE = "TEST";

    //employee table columns
    public static final String EMPLOYEE_USERNAME_COL = "EMPLOYEE_USERNAME";
    public static final String EMPLOYEE_PASSWORD_COL = "EMPLOYEE_PASSWORD";
    public static final String EMPLOYEE_EMAIL_COL = "EMPLOYEE_EMAIL";
    public static final String EMPLOYEE_FIRST_NAME_COL = "EMPLOYEE_FIRST_NAME";
    public static final String EMPLOYEE_LAST_NAME_COL = "EMPLOYEE_LAST_NAME";
    public static final String EMPLOYEE_TYPE_COL = "EMPLOYEE_TYPE";
    //customer table columns

    public static final String  CUSTOMER_FIRST_NAME_COL = "CUSTOMER_FIRST_NAME";
    public static final String  CUSTOMER_LAST_NAME_COL = "CUSTOMER_LAST_NAME";
    public static final String  CUSTOMER_EMAIL_COL = "CUSTOMER_EMAIL";
    public static final String  CUSTOMER_TELEPHONE_COL = "CUSTOMER_TELEPHONE";
    public static final String  CUSTOMER_ADDRESS_COL = "CUSTOMER_ADDRESS";
    public static final String  CUSTOMER_PLATE_NUMBER_COL = "CUSTOMER_PLATE_NUMBER";
    //appointment table columns
    public static final String APPOINTMENT_PLATE_NUMBER_COL = "APPOINTMENT_PLATE_NUMBER";
    public static final String  APPOINTMENT_DATE_COL = "APPOINTMENT_DATE";
    public static final String  APPOINTMENT_TIME_COL = "APPOINTMENT_TIME";
    //vehicle table columns
    public static final String  VEHICLE_PLATE_NUMBER_COL = "VEHICLE_PLATE_NUMBER";
    public static final String  VEHICLE_TESTED_BY_COL = "VEHICLE_TESTED_BY";
    public static final String  VEHICLE_MAKE_COL= "VEHICLE_MAKE";
    public static final String  VEHICLE_TEST_DATE_COL= "VEHICLE_TEST_DATE";
    public static final String  VEHICLE_MODEL_COL= "VEHICLE_MODEL";
    public static final String  VEHICLE_MILEAGE_COL= "VEHICLE_MILEAGE";
    public static final String  VEHICLE_COLOR_COL = "VEHICLE_COLOR";
    public static final String  VEHICLE_YEAR_COL = "VEHICLE_YEAR";
    public static final String  VEHICLE_STATUS_COL = "VEHICLE_STATUS";
    //part table columns
    public static final String PART_NAME_COL = "PART_NAME";
    public static final String PART_TESTING_METHOD_COL = "TESTING_METHOD";

    //test table columns
    public static final String  TEST_VEHICLE_PLATE_NUMBER_COL = "TEST_VEHICLE_PLATE_NUMBER"; //FK
    public static final String  TEST_EMPLOYEE_USERNAME_COL = "TEST_EMPLOYEE_USERNAME"; //FK
    public static final String  TEST_PART_NAME_COL = "TEST_PART_NAME";
    public static final String  TEST_RESULT_COL = "TEST_RESULT";
    public static final String  TEST_DETAILS_COL = "TEST_DETAILS";


    public DatabaseHelper(Context context) {
        super(context, db_name, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //EMPLOYEE TABLE
        db.execSQL("create table " + EMPLOYEE_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "EMPLOYEE_USERNAME TEXT," +
                "EMPLOYEE_PASSWORD TEXT," +
                "EMPLOYEE_EMAIL TEXT," +
                "EMPLOYEE_FIRST_NAME TEXT," +
                "EMPLOYEE_LAST_NAME TEXT," +
                "EMPLOYEE_TYPE INT)");

        //CUSTOMER TABLE
        db.execSQL("create table " + CUSTOMER_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "CUSTOMER_FIRST_NAME TEXT," +
                "CUSTOMER_LAST_NAME TEXT," +
                "CUSTOMER_EMAIL TEXT," +
                "CUSTOMER_TELEPHONE TEXT," +
                "CUSTOMER_ADDRESS TEXT," +
                "CUSTOMER_PLATE_NUMBER TEXT)");

        //APPOINTMENT TABLE
        db.execSQL("create table " + APPOINTMENT_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "APPOINTMENT_DATE TEXT," +
                "APPOINTMENT_TIME TEXT," +
                "APPOINTMENT_PLATE_NUMBER TEXT)");

        //VEHICLE TABLE
        db.execSQL("create table " + VEHICLE_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "VEHICLE_PLATE_NUMBER TEXT," +
                "VEHICLE_TEST_DATE TEXT," +
                "VEHICLE_MAKE TEXT," +
                "VEHICLE_MODEL TEXT," +
                "VEHICLE_MILEAGE TEXT," +
                "VEHICLE_TESTED_BY TEXT," +
                "VEHICLE_COLOR TEXT," +
                "VEHICLE_YEAR TEXT," +
                "VEHICLE_STATUS TEXT)");

        //PART TABLE
        db.execSQL("create table " + PART_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "PART_NAME TEXT," +
                "PART_TESTING_METHOD TEXT)");

        //PART ITEM TABLE
        db.execSQL("create table " + PART_ITEM_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "PART_ID INTEGER," +
                "PART_ITEM_NAME TEXT," +
                "PART_TIME_FAILURE_DETAILS TEXT)");

        //TEST TABLE
        db.execSQL("create table " + TEST_TABLE + "( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "TEST_VEHICLE_PLATE_NUMBER TEXT," +
                "TEST_EMPLOYEE_USERNAME TEXT," +
                "TEST_PART_NAME TEXT," +
                "TEST_RESULT TEXT," +
                "TEST_DETAILS TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS "+ EMPLOYEE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+ CUSTOMER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+ APPOINTMENT_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+ VEHICLE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+ PART_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+ PART_ITEM_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+ TEST_TABLE);

    }

    //FUNCTIONS

    //Login
    String checkUser(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("EMPLOYEE", null, "EMPLOYEE_USERNAME=?",new String[]{username},null,null,null);
        if(cursor.getCount()<1){
            cursor.close();
            return "Username doesn't exist.";
        }
        //IF THERE' A USER.. RETURN THE PASSWORD
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex("EMPLOYEE_PASSWORD"));
        return password;
    }

    //Check if username exists
    int checkUsername(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("EMPLOYEE", null, "EMPLOYEE_USERNAME=?",new String[]{username},null,null,null);
        if(cursor.getCount()<1){
            cursor.close();
            return 0;
        }
        else{
            return 1;
        }
    }

    void delete_username(String username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + EMPLOYEE_TABLE + " WHERE EMPLOYEE_USERNAME ='"+username+"'");
        db.close();
    }

    //Login
    int checkPlateNumber(String plateNumber){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("APPOINTMENT", null, "APPOINTMENT_PLATE_NUMBER=?",new String[]{plateNumber},null,null,null);
        if(cursor.getCount()>0){
            cursor.close();
            return 1;
        }
        else{
            cursor.close();
            return 0;
        }
    }

    int isAdmin(String username){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("EMPLOYEE", null, "EMPLOYEE_USERNAME=?",new String[]{username},null,null,null);
        if( cursor != null && cursor.moveToFirst()) {
            int usertype = cursor.getInt(cursor.getColumnIndex("EMPLOYEE_TYPE"));
            return usertype;
        }
        else{
            return 0;
        }
    }

    //add New Mechanic
    void addNewEmployee(String username,String password,String email,String firstName,String lastName, int employeeType){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EMPLOYEE_USERNAME_COL,username);
        contentValues.put(EMPLOYEE_PASSWORD_COL,password);
        contentValues.put(EMPLOYEE_EMAIL_COL,email);
        contentValues.put(EMPLOYEE_FIRST_NAME_COL,firstName);
        contentValues.put(EMPLOYEE_LAST_NAME_COL,lastName);
        contentValues.put(EMPLOYEE_TYPE_COL,employeeType);
        db.insert( EMPLOYEE_TABLE,null,contentValues);

    }

    void addCustomerDetails(String firstName,String lastName,String email,String telephone,String address,String vehiclePlateNumber){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CUSTOMER_FIRST_NAME_COL,firstName);
        contentValues.put(CUSTOMER_LAST_NAME_COL,lastName);
        contentValues.put(CUSTOMER_EMAIL_COL,email);
        contentValues.put(CUSTOMER_TELEPHONE_COL,telephone);
        contentValues.put(CUSTOMER_ADDRESS_COL,address);
        contentValues.put(CUSTOMER_PLATE_NUMBER_COL,vehiclePlateNumber);
        db.insert(CUSTOMER_TABLE,null,contentValues);
    }

    void updateCustomerDetails(String firstName,String lastName,String email,String telephone,String address,String vehiclePlateNumber){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CUSTOMER_FIRST_NAME_COL,firstName);
        contentValues.put(CUSTOMER_LAST_NAME_COL,lastName);
        contentValues.put(CUSTOMER_EMAIL_COL,email);
        contentValues.put(CUSTOMER_TELEPHONE_COL,telephone);
        contentValues.put(CUSTOMER_ADDRESS_COL,address);
        contentValues.put(CUSTOMER_PLATE_NUMBER_COL,vehiclePlateNumber);
        db.update(CUSTOMER_TABLE,contentValues,"CUSTOMER_PLATE_NUMBER = ?",new String[]{vehiclePlateNumber});
    }


    //Appointment Methods
    void addAppointment(String days,String month,String year,String time,String plateNumber ){

        String date = days + " " + month + " " + year;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(APPOINTMENT_PLATE_NUMBER_COL,plateNumber);
        contentValues.put(APPOINTMENT_DATE_COL,date);
        contentValues.put(APPOINTMENT_TIME_COL,time);
        db.insert(APPOINTMENT_TABLE,null,contentValues);

    }

    //check if there' already an appointment

    int checkAppointmentTime(String days,String month,String year,String time){
        String date = days + " " + month + " " + year;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("APPOINTMENT", null, "APPOINTMENT_DATE=?",new String[]{date},null,null,null);

        if(cursor.getCount()>0){

            Cursor c = db.query("APPOINTMENT", null, "APPOINTMENT_TIME=?",new String[]{time},null,null,null);
            if(c.getCount()>0){
                return 1;
            }else{
                return 0;
            }
        }
        else{
            cursor.close();
            return 0;
        }

    }

    //get appointment details
    Cursor getAppointment(String plateNumber) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM APPOINTMENT WHERE APPOINTMENT_PLATE_NUMBER = '" + plateNumber + "'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;

    }


    //update appointment

    //Appointment Methods
    void updateAppointment(String days,String month,String year,String time,String plateNumber ){

        String date = days + " " + month + " " + year;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(APPOINTMENT_PLATE_NUMBER_COL,plateNumber);
        contentValues.put(APPOINTMENT_DATE_COL,date);
        contentValues.put(APPOINTMENT_TIME_COL,time);
        db.update(APPOINTMENT_TABLE,contentValues,"APPOINTMENT_PLATE_NUMBER = ?",new String[]{plateNumber});

    }

    //get appointment list
    Cursor getAllAppointment() {

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.query(APPOINTMENT_TABLE,
                new String[] {"_id", APPOINTMENT_PLATE_NUMBER_COL,APPOINTMENT_DATE_COL,APPOINTMENT_TIME_COL},
                null,
                null,
                null,
                null,
                null);

        return c;
    }

    //get appointment list
    Cursor getAllUsers() {

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.query(EMPLOYEE_TABLE,
                new String[] {"_id", EMPLOYEE_USERNAME_COL,EMPLOYEE_TYPE_COL},
                null,
                null,
                null,
                null,
                null);

        return c;
    }

    void delete_appointment(String plateNumber)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + APPOINTMENT_TABLE + " WHERE APPOINTMENT_PLATE_NUMBER ='"+plateNumber+"'");
        db.execSQL("DELETE FROM " + CUSTOMER_TABLE + " WHERE CUSTOMER_PLATE_NUMBER ='"+plateNumber+"'");
        db.execSQL("DELETE FROM " + VEHICLE_TABLE + " WHERE VEHICLE_PLATE_NUMBER ='"+plateNumber+"'");
        db.close();
    }

    void delete_appointment_schedule(String plateNumber)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + APPOINTMENT_TABLE + " WHERE APPOINTMENT_PLATE_NUMBER ='"+plateNumber+"'");
        db.close();
    }

    //Get appointment search result
    Cursor getAppointmentSearchResult(String plateNumber){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM APPOINTMENT WHERE APPOINTMENT_PLATE_NUMBER LIKE '" + plateNumber + "%'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }


    Cursor toBeTested(String date){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM APPOINTMENT WHERE APPOINTMENT_DATE= '" + date + "'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }

    //get customer primary ID
    int getCustomerID(String firstName,String lastName){

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM CUSTOMER_TABLE WHERE CUSTOMER_FIRST_NAME = " + firstName + " AND " + "CUSTOMER_LAST_NAME = " + lastName;
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null) {
            int customer_id = cursor.getInt(cursor.getColumnIndex("_id"));
            return customer_id;
        }
        else{
            return 0;
        }
    }

    //get customer details
        Cursor getCustomer(String plateNumber) {

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM CUSTOMER WHERE CUSTOMER_PLATE_NUMBER = '" + plateNumber + "'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }

    //vehicle methods

    void addVehicle(String plateNumber,String make,String model, String mileage, String color,String year,String status,String testDate){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(VEHICLE_PLATE_NUMBER_COL,plateNumber);
        contentValues.put(VEHICLE_MAKE_COL,make);
        contentValues.put(VEHICLE_MODEL_COL,model);
        contentValues.put(VEHICLE_MILEAGE_COL,mileage);
        contentValues.put(VEHICLE_COLOR_COL,color);
        contentValues.put(VEHICLE_YEAR_COL,year);
        contentValues.put(VEHICLE_STATUS_COL,status);
        contentValues.put(VEHICLE_TEST_DATE_COL,testDate);
        contentValues.put(VEHICLE_TESTED_BY_COL,"");
        db.insert(VEHICLE_TABLE,null,contentValues);
    }

    void updateVehicle(String plateNumber,String make,String model, String mileage, String color,String year,String status,String testDate){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(VEHICLE_PLATE_NUMBER_COL,plateNumber);
        contentValues.put(VEHICLE_MAKE_COL,make);
        contentValues.put(VEHICLE_MODEL_COL,model);
        contentValues.put(VEHICLE_MILEAGE_COL,mileage);
        contentValues.put(VEHICLE_COLOR_COL,color);
        contentValues.put(VEHICLE_YEAR_COL,year);
        contentValues.put(VEHICLE_STATUS_COL,status);
        contentValues.put(VEHICLE_TEST_DATE_COL,testDate);
        db.update(VEHICLE_TABLE,contentValues,"VEHICLE_PLATE_NUMBER = ?",new String[]{plateNumber});
    }

    void updateVehicleStatus(String plateNumber,String status){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(VEHICLE_STATUS_COL,status);
        db.update(VEHICLE_TABLE,contentValues,"VEHICLE_PLATE_NUMBER = ?",new String[]{plateNumber});
    }

    String getMechanicName(String plateNumber){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("VEHICLE", null, "VEHICLE_PLATE_NUMBER=?",new String[]{plateNumber},null,null,null);
        if(cursor.getCount()<1){
            cursor.close();
            return "Untested";
        }
        //IF THERE' A USER.. RETURN THE PASSWORD
        cursor.moveToFirst();
        String mechanicName = cursor.getString(cursor.getColumnIndex("VEHICLE_TESTED_BY"));
        return mechanicName;
    }

    void addMechanicName(String plateNumber,String mechanicName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(VEHICLE_TESTED_BY_COL,mechanicName);
        db.update(VEHICLE_TABLE,contentValues,"VEHICLE_PLATE_NUMBER = ?",new String[]{plateNumber});
    }

    //get vehicle details
    Cursor getVehicle(String plateNumber) {

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM VEHICLE WHERE VEHICLE_PLATE_NUMBER = '" + plateNumber + "'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }

    //get untested cars details
    Cursor untestedCars(String date) {

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM VEHICLE WHERE VEHICLE_TEST_DATE = '" + date + "' AND VEHICLE_STATUS = 'UNTESTED'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }

    //get tested Vehicles
    //get vehicle details
    Cursor getAllTestedVehicle() {

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM VEHICLE WHERE VEHICLE_STATUS = 'TESTED'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }

    Cursor getTestedCarSearchResult(String plateNumber){

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM VEHICLE WHERE VEHICLE_STATUS = 'TESTED' AND VEHICLE_PLATE_NUMBER LIKE '" + plateNumber + "%'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }
        return cursor;
    }

    //add tested parts
    void addTestedParts(String plateNumber,String partName,String testResult,String testDetails){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TEST_VEHICLE_PLATE_NUMBER_COL,plateNumber);
        contentValues.put(TEST_PART_NAME_COL,partName);
        contentValues.put(TEST_RESULT_COL,testResult);
        contentValues.put(TEST_DETAILS_COL,testDetails);
        db.insert(TEST_TABLE,null,contentValues);

    }

    Cursor getTestedParts(String plateNumber) {

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM TEST WHERE TEST_VEHICLE_PLATE_NUMBER = '" + plateNumber + "'";
        Cursor  cursor = db.rawQuery(query,null);
        if (cursor != null){
            cursor.moveToFirst();
            return cursor;
        }

        return cursor;
    }

    //get parts
    Cursor getParts() {

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(PART_TABLE,
                new String[] {"_id",PART_NAME_COL,PART_TESTING_METHOD_COL},
                null,
                null,
                null,
                null,
                null);

        return cursor;
    }




}
