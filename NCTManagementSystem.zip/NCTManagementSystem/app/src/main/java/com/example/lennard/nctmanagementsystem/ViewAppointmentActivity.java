package com.example.lennard.nctmanagementsystem;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

/**
 * Created by lennard on 27/08/2017.
 */

public class ViewAppointmentActivity extends Activity{

    //DATABASE

    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_appointment);

        search();
        displayAppointment();

    }

    private void search() {
        final EditText searchQuery= (EditText)findViewById(R.id.etSearchTestedCar);
        searchQuery.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String plateNumber = searchQuery.getText().toString();
                searchAppointment(plateNumber);
            }
        });
    }

    private void searchAppointment(String plateNumber) {

        if(plateNumber.equals("")){
            displayAppointment();
        }
        else {
            //display the searched views
            DatabaseHelper myDb = new DatabaseHelper(this);
            Cursor c = myDb.getAppointmentSearchResult(plateNumber);
            //display all appointment sorted by date
            DatabaseHelper db = new DatabaseHelper(this);
            String[] from = new String[]{DatabaseHelper.APPOINTMENT_PLATE_NUMBER_COL, DatabaseHelper.APPOINTMENT_DATE_COL, DatabaseHelper.APPOINTMENT_TIME_COL};
            int[] to = new int[]{R.id.tV_view_appointment_plateNumber, R.id.tV_list_appointment_date, R.id.tV_list_appointment_time};
            SimpleCursorAdapter appointmentAdapter;
            appointmentAdapter = new SimpleCursorAdapter(this, R.layout.appointment_list_layout, c, from, to, 0);
            ListView appointmentList = (ListView) findViewById(R.id.lV_appointments);
            appointmentList.setAdapter(appointmentAdapter);
            appointmentList.setTextFilterEnabled(true);

            //DISPLAY APPOINTMENT DETAILS
            appointmentList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1,
                                        int position, long arg3) {

                    final TextView tV_view_appointment_plateNumber = arg1.findViewById(R.id.tV_view_appointment_plateNumber);
                    final TextView tV_edit_btn = arg1.findViewById(R.id.tV_appointment_edit);
                    final TextView tV_remove_btn = arg1.findViewById(R.id.tV_appointment_remove);

                    final String plateNumber = tV_view_appointment_plateNumber.getText().toString();

                    tV_remove_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            deleteAppointment(plateNumber);
                        }
                    });

                    tV_edit_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            editAppointment(plateNumber);
                        }
                    });
                }
            });
        }
    }

    void displayAppointment() {

        //display all appointment sorted by date
        DatabaseHelper db = new DatabaseHelper(this);
        Cursor c = db.getAllAppointment();
        String[] from = new String[]{DatabaseHelper.APPOINTMENT_PLATE_NUMBER_COL, DatabaseHelper.APPOINTMENT_DATE_COL, DatabaseHelper.APPOINTMENT_TIME_COL};
        int[] to = new int[]{R.id.tV_view_appointment_plateNumber, R.id.tV_list_appointment_date, R.id.tV_list_appointment_time};
        SimpleCursorAdapter appointmentAdapter;
        appointmentAdapter = new SimpleCursorAdapter(this, R.layout.appointment_list_layout, c, from, to, 0);
        ListView appointmentList = (ListView) findViewById(R.id.lV_appointments);
        appointmentList.setAdapter(appointmentAdapter);
        appointmentList.setTextFilterEnabled(true);

        //DISPLAY APPOINTMENT DETAILS
        appointmentList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long arg3) {

                final TextView tV_view_appointment_plateNumber = arg1.findViewById(R.id.tV_view_appointment_plateNumber);
                final TextView tV_edit_btn = arg1.findViewById(R.id.tV_appointment_edit);
                final TextView tV_remove_btn = arg1.findViewById(R.id.tV_appointment_remove);

                final String plateNumber = tV_view_appointment_plateNumber.getText().toString();

                tV_remove_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        deleteAppointment(plateNumber);
                    }
                });

                tV_edit_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editAppointment(plateNumber);
                    }
                });
            }
        });
    }

    //dialog to confirm appointment deletion
    private void deleteAppointment(final String plateNumber) {

        AlertDialog.Builder builder = new AlertDialog.Builder(ViewAppointmentActivity.this);
        builder.setTitle(plateNumber);
        builder.setMessage("Do you want to remove this appointment?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                //delete appointment ID
                //display all appointment sorted by date
                DatabaseHelper db = new DatabaseHelper(ViewAppointmentActivity.this);
                db.delete_appointment(plateNumber);
                Toast.makeText(ViewAppointmentActivity.this, "Appointment deleted", Toast.LENGTH_SHORT).show();
                //refresh the appointment l
                displayAppointment();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    //dialog to confirm appointment deletion
    private void editAppointment(final String plateNumber) {

        AlertDialog.Builder builder = new AlertDialog.Builder(ViewAppointmentActivity.this);
        builder.setTitle(plateNumber);
        builder.setMessage("Do you want to edit this appointment?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {


                DatabaseHelper db = new DatabaseHelper(getApplicationContext());

                //change the content view
                setContentView(R.layout.create_appointment_layout);

                //cursors
                final Cursor a = db.getCustomer(plateNumber);
                final Cursor b = db.getAppointment(plateNumber);
                final Cursor c = db.getVehicle(plateNumber);

                final EditText et_firstName = (EditText)findViewById(R.id.eT_customer_firstName);
                final EditText et_lastName = (EditText)findViewById(R.id.eT_customer_lastName);
                final EditText et_email = (EditText)findViewById(R.id.eT_customer_email);
                final EditText et_telephone = (EditText)findViewById(R.id.eT_customer_telephone);
                final EditText et_address = (EditText)findViewById(R.id.et_customer_address);

                //display the values of the current appointment
                et_firstName.setText(a.getString(a.getColumnIndex("CUSTOMER_FIRST_NAME")));
                et_lastName.setText(a.getString(a.getColumnIndex("CUSTOMER_LAST_NAME")));
                et_email.setText(a.getString(a.getColumnIndex("CUSTOMER_EMAIL")));
                et_telephone.setText(a.getString(a.getColumnIndex("CUSTOMER_TELEPHONE")));
                et_address.setText(a.getString(a.getColumnIndex("CUSTOMER_ADDRESS")));

                final Spinner day =(Spinner) findViewById(R.id.spinner_user_type);
                final Spinner month =(Spinner) findViewById(R.id.date_month);
                final Spinner year =(Spinner) findViewById(R.id.date_year);
                final Spinner time =(Spinner) findViewById(R.id.time);

                //Spinner Adapter
                ArrayAdapter<CharSequence> day_adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                        R.array.days, android.R.layout.simple_spinner_item);
                ArrayAdapter<CharSequence> month_adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                        R.array.months, android.R.layout.simple_spinner_item);
                ArrayAdapter<CharSequence> year_adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                        R.array.year, android.R.layout.simple_spinner_item);
                ArrayAdapter<CharSequence> time_adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                        R.array.time, android.R.layout.simple_spinner_item);

                day_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                month_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                year_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                time_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                day.setAdapter(day_adapter);
                month.setAdapter(month_adapter);
                year.setAdapter(year_adapter);
                time.setAdapter(time_adapter);

                //Display the chosen appointment time and date
                String s_date = b.getString(b.getColumnIndex("APPOINTMENT_DATE"));
                String s_time = b.getString(b.getColumnIndex("APPOINTMENT_TIME"));
                String[] split_date = s_date.split("\\s+");

                //split the date column
                String s_day = split_date[0];
                String s_month = split_date[1];
                String s_year = split_date[2];

                //find the position of spinner
                int day_pos = day_adapter.getPosition(s_day);
                int month_pos = month_adapter.getPosition(s_month);
                int year_pos = year_adapter.getPosition(s_year);
                int time_pos = time_adapter.getPosition(s_time);

                //set the position of the spinner
                day.setSelection(day_pos);
                month.setSelection(month_pos);
                year.setSelection(year_pos);
                time.setSelection(time_pos);

                final TextView next = (TextView)findViewById(R.id.tV_appointment_next);

                next.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //Variables
                        final String firstName = et_firstName.getText().toString();
                        final String lastName = et_lastName.getText().toString();
                        final String email = et_email.getText().toString();
                        final String telephone = et_telephone.getText().toString();
                        final String address = et_address.getText().toString();

                        final String selected_day = day.getSelectedItem().toString();
                        final String selected_month = month.getSelectedItem().toString();
                        final String selected_year = year.getSelectedItem().toString();
                        final String selected_time = time.getSelectedItem().toString();

                        //Error Check
                        if(firstName.equals("") || lastName.equals("") || email.equals("") || address.equals("") || telephone.equals("") || selected_day.equals("") || selected_month.equals("") || selected_year.equals("") || selected_time.equals("")){

                            Toast.makeText(getApplicationContext(), "Empty Fields!", Toast.LENGTH_LONG).show();
                        }
                        else{


                            AlertDialog.Builder builder = new AlertDialog.Builder(ViewAppointmentActivity.this);
                            builder.setTitle("Confirm Details");
                            builder.setMessage("Are all details correct?");
                            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                                //if the user confirm details
                                public void onClick(DialogInterface dialog, int which) {

                                    //check time chosen
                                    //int time_check = myDb.checkAppointmentTime(selected_day,selected_month,selected_year,selected_time);
                                    int time_check = 0;

                                    if(time_check == 1){
                                        Toast.makeText(getApplicationContext(), "Please choose a different time", Toast.LENGTH_LONG).show();
                                        dialog.dismiss();
                                    }
                                    else {

                                        //change to vehicle layout
                                        setContentView(R.layout.vehicle_detail_layout);

                                        TextView book = (TextView) findViewById(R.id.tV_appointment_book);

                                        final EditText et_plateNumber = (EditText) findViewById(R.id.eT_vehicle_plateNumber);
                                        final EditText et_make = (EditText) findViewById(R.id.eT_vehicle_make);
                                        final EditText et_model = (EditText) findViewById(R.id.eT_vehicle_model);
                                        final EditText et_mileage = (EditText) findViewById(R.id.eT_vehicle_mileage);
                                        final EditText et_color = (EditText) findViewById(R.id.eT_vehicle_color);
                                        final EditText et_car_year = (EditText) findViewById(R.id.eT_vehicle_year);

                                        //display the values of the current appointment
                                        et_plateNumber.setText(plateNumber);
                                        et_make.setText(c.getString(c.getColumnIndex("VEHICLE_MAKE")));
                                        et_model.setText(c.getString(c.getColumnIndex("VEHICLE_MODEL")));
                                        et_mileage.setText(c.getString(c.getColumnIndex("VEHICLE_MILEAGE")));
                                        et_color.setText(c.getString(c.getColumnIndex("VEHICLE_COLOR")));
                                        et_car_year.setText(c.getString(c.getColumnIndex("VEHICLE_YEAR")));

                                        book.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {

                                                //Variables
                                                String new_plate_Number = et_plateNumber.getText().toString();
                                                if(new_plate_Number.equals(plateNumber)){
                                                    new_plate_Number = plateNumber;
                                                }else{
                                                    //do nothing
                                                }
                                                final String final_plate_number = new_plate_Number;
                                                final String make = et_make.getText().toString();
                                                final String model = et_model.getText().toString();
                                                final String mileage = et_mileage.getText().toString();
                                                final String color = et_color.getText().toString();
                                                final String year = et_car_year.getText().toString();

                                                if (new_plate_Number.equals("") || make.equals("") || model.equals("") || mileage.equals("") || color.equals("") || year.equals("")) {
                                                    Toast.makeText(getApplicationContext(), "Empty Fields!", Toast.LENGTH_LONG).show();
                                                } else {

                                                    AlertDialog.Builder builder = new AlertDialog.Builder(ViewAppointmentActivity.this);
                                                    builder.setTitle("Confirm Details");
                                                    builder.setMessage("Are all details correct?");

                                                    //yes option
                                                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                        public void onClick(DialogInterface dialog, int which) {

                                                            //error check for plate Number
                                                            DatabaseHelper db = new DatabaseHelper(getApplicationContext());
                                                            int result = db.checkPlateNumber(final_plate_number);

                                                            if (result == 0) {

                                                                //Add Customer
                                                                db.addCustomerDetails(firstName, lastName, email, telephone, address, final_plate_number);
                                                                //Add to Appointment
                                                                db.addAppointment(selected_day, selected_month, selected_year, selected_time, final_plate_number);
                                                                String testDate = selected_day + " " + selected_month + " " + selected_year;
                                                                //Add Vehicle Details
                                                                myDb.addVehicle(plateNumber, make, model, mileage, color, year,"UNTESTED",testDate);
                                                                //Drop old appointment from the old plate number
                                                                db.delete_appointment(plateNumber);
                                                                Toast.makeText(getApplicationContext(), "Appointment Added", Toast.LENGTH_LONG).show();
                                                                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                                                                startActivity(intent);

                                                            } else {
                                                                //UPDATE CUSTOMER DETAILS
                                                                db.updateCustomerDetails(firstName, lastName, email, telephone, address, plateNumber);
                                                                //UPDATE APPOINTMENT DETAILS
                                                                db.updateAppointment(selected_day, selected_month, selected_year, selected_time, plateNumber);
                                                                //UPDATE VEHICLE
                                                                String testDate = selected_day + " " + selected_month + " " + selected_year;
                                                                db.updateVehicle(plateNumber, make, model, mileage, color, year,"UNTESTED",testDate);

                                                                Toast.makeText(getApplicationContext(), "Appointment Updated", Toast.LENGTH_LONG).show();
                                                                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                                                                startActivity(intent);
                                                            }
                                                        }
                                                    });

                                                    //no option
                                                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

                                                        @Override
                                                        public void onClick(DialogInterface dialog, int which) {
                                                            // Do nothing
                                                            dialog.dismiss();
                                                        }
                                                    });

                                                    AlertDialog alert = builder.create();
                                                    alert.show();

                                                }
                                            }
                                        });
                                    }
                                }
                            });

                            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // Do nothing
                                    dialog.dismiss();
                                }
                            });

                            AlertDialog alert = builder.create();
                            alert.show();

                        }
                    }
                });

            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

}


