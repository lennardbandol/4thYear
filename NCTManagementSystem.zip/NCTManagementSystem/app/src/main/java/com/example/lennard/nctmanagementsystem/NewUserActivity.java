package com.example.lennard.nctmanagementsystem;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by lennard on 30/08/2017.
 */

public class NewUserActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.user_list);

        displayUsers();

        TextView add_new_user_btn = (TextView)findViewById(R.id.tV_add_new_user);
        add_new_user_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createNewUser();
            }
        });
    }

    void createNewUser(){


        setContentView(R.layout.new_user_layout);
        //Set Spinner
        final Spinner user_type = (Spinner) findViewById(R.id.spinner_user_type);
        final ArrayAdapter<CharSequence> userType_adapter = ArrayAdapter.createFromResource(this,
                R.array.userType, android.R.layout.simple_spinner_item);
        userType_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        user_type.setAdapter(userType_adapter);

        final EditText et_n_username = (EditText) findViewById(R.id.eT_employee_username);
        final EditText et_n_password = (EditText) findViewById(R.id.eT_employee_password);
        final EditText et_n_email = (EditText) findViewById(R.id.eT_employee_email);
        final EditText et_n_first_name = (EditText) findViewById(R.id.eT_employee_first_name);
        final EditText et_n_last_name = (EditText) findViewById(R.id.eT_employe_last_name);

        final TextView create_user_btn = (TextView)findViewById(R.id.tV_create_user_btn);

        create_user_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Variables
                final String n_username = et_n_username.getText().toString();
                final String n_password = et_n_password.getText().toString();
                final String n_email = et_n_email.getText().toString();
                final String n_first_name = et_n_first_name.getText().toString();
                final String n_last_name = et_n_last_name.getText().toString();

                final Spinner spinner_user_type =(Spinner) findViewById(R.id.spinner_user_type);
                final String user_type = spinner_user_type.getSelectedItem().toString();

                //Error Check
                if(n_username.equals("") || n_password.equals("") || n_email.equals("") || n_first_name.equals("") || n_last_name.equals("")){
                    Toast.makeText(getApplicationContext(), "Empty Fields!", Toast.LENGTH_SHORT).show();
                }else{
                    //check if use exists
                    DatabaseHelper myDb = new DatabaseHelper(getApplicationContext());
                    int result = myDb.checkUsername(n_username);
                    if(result == 0){
                        //Theres no username
                        if(user_type.equals("Mechanic")){
                            myDb.addNewEmployee(n_username,n_password,n_email,n_first_name,n_last_name,0);
                            Intent intent = new Intent(NewUserActivity.this,AdminActivity.class);
                            Toast.makeText(getApplicationContext(), "Added New Mechanic", Toast.LENGTH_SHORT).show();
                            startActivity(intent);
                        }else{
                            myDb.addNewEmployee(n_username,n_password,n_email,n_first_name,n_last_name,1);
                            Intent intent = new Intent(NewUserActivity.this,AdminActivity.class);
                            Toast.makeText(getApplicationContext(), "Added New Administrator", Toast.LENGTH_SHORT).show();
                            startActivity(intent);
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), "Username Already Exists", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }

    void displayUsers(){

        //display all users
        DatabaseHelper db = new DatabaseHelper(this);
        Cursor c = db.getAllUsers();
        String[] from = new String[]{DatabaseHelper.EMPLOYEE_USERNAME_COL};
        int[] to = new int[]{R.id.tV_list_userName};
        SimpleCursorAdapter userAdapter;
        userAdapter = new SimpleCursorAdapter(this, R.layout.user_list_item, c, from, to, 0);
        ListView userList = (ListView) findViewById(R.id.lV_user_list);
        userList.setAdapter(userAdapter);
        userList.setTextFilterEnabled(true);

        //DISPLAY USERS
        userList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long arg3) {

                final TextView tV_userName = arg1.findViewById(R.id.tV_list_userName);
                final String username = tV_userName.getText().toString();

                AlertDialog.Builder builder = new AlertDialog.Builder(NewUserActivity.this);
                builder.setTitle(username);
                builder.setMessage("Do you want to remove this employee?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //delete appointment ID
                        //display all appointment sorted by date
                        DatabaseHelper db = new DatabaseHelper(NewUserActivity.this);
                        db.delete_username(username);
                        Toast.makeText(NewUserActivity.this, "User deleted", Toast.LENGTH_SHORT).show();
                        displayUsers();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Do nothing
                        dialog.dismiss();
                    }
                });


            }
        });
    }
}
