package com.example.lennard.nctmanagementsystem;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    //DATABASE

    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);

        //initialize database
        myDb = new DatabaseHelper(this);

        //setup
        Populate();

        //Login
        Login();

    }

    private void Login(){
        final EditText username = (EditText)findViewById(R.id.eT_LoginUsername);
        final EditText password = (EditText)findViewById(R.id.eT_LoginPassword);
        Button LoginButton = (Button)findViewById(R.id.btn_Login);

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //buffer variables for username and password
                final String entered_username = username.getText().toString();
                final String entered_password = password.getText().toString();

                //get the password from the database.
                String dbPassword = myDb.checkUser(entered_username);

                //check user type
                int isAdmin = myDb.isAdmin(entered_username);

                //Error Checks
                if(entered_username.equals("") || entered_password.equals("")) {
                    Toast.makeText(LoginActivity.this, "Please Don't Leave Empty Fields!", Toast.LENGTH_LONG).show();
                }
                if(isAdmin == 1){
                    //now checks if the user entered the correct password
                    if(entered_password.equals(dbPassword)){
                        SharedPreferences mPrefs = getSharedPreferences("VALUE", 0);
                        SharedPreferences.Editor editor = mPrefs.edit();
                        editor.putString("username",entered_username);
                        editor.commit();
                        Toast.makeText(LoginActivity.this, "Welcome " + entered_username, Toast.LENGTH_LONG).show();
                        startActivity(new Intent(LoginActivity.this, AdminActivity.class));
                        finish();
                    }
                    else{
                        //entered wrong password
                        Toast.makeText(LoginActivity.this, "Incorrect logged in details.", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    //now checks if the user entered the correct password
                    if(entered_password.equals(dbPassword)){

                        SharedPreferences mPrefs = getSharedPreferences("VALUE", 0);
                        SharedPreferences.Editor editor = mPrefs.edit();
                        editor.putString("username",entered_username);
                        editor.commit();
                        Toast.makeText(LoginActivity.this, "Welcome " + entered_username, Toast.LENGTH_LONG).show();
                        startActivity(new Intent(LoginActivity.this, MechanicActivity.class));
                        finish();

                    }
                    else{
                        //entered wrong password
                        Toast.makeText(LoginActivity.this, "Incorrect logged in details.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void Populate(){
        SharedPreferences populateDb = PreferenceManager.getDefaultSharedPreferences(this);
        boolean checkFirstRun = populateDb.getBoolean("firstRun", true);

        if(checkFirstRun) {

            //UNCOMMENT FOR TESTING BUT IT'S BETTER TO CREATE NEW

            //Users
            myDb.addNewEmployee("Mechanic", "Mechanic", "lennardglenn@gmail.com", "Lennard", "Bandol", 0);
            myDb.addNewEmployee("Admin", "Admin", "lennardglenn@gmail.com", "Lennard", "Bandol", 1);

//            //cars
//            myDb.addVehicle("CAR1", "Ford", "Focus", "200000", "RED", "2016", "TESTED","31 7 2017");
//            myDb.addVehicle("CAR2", "Ford", "Fiesta", "200000", "RED", "2015", "TESTED","31 7 2017");
//            myDb.addVehicle("CAR3", "Audi", "A4", "200000", "RED", "2014", "UNTESTED","31 7 2017");
//            myDb.addVehicle("CAR4", "Audi", "A6", "200000", "BLACK", "2013", "UNTESTED","31 7 2017");
//            myDb.addVehicle("CAR5", "Audi", "A4", "200000", "RED", "2014", "UNTESTED","31 7 2017");
//            myDb.addVehicle("CAR6", "Audi", "A6", "200000", "BLACK", "2013", "UNTESTED","31 7 2017");
//            myDb.addVehicle("CAR7", "Audi", "A4", "200000", "RED", "2014", "UNTESTED","31 7 2017");
//            myDb.addVehicle("CAR8", "Audi", "A6", "200000", "BLACK", "2013", "UNTESTED","31 7 2017");
//
//            //change time
//            myDb.addAppointment("31", "7", "2017", "10:30", "171-D-12345");
//            myDb.addAppointment("31", "7", "2017", "9:30", "CAR2");
//            myDb.addAppointment("31", "7", "2017", "12:30", "CAR3");
//            myDb.addAppointment("31", "7", "2017", "16:30", "CAR4");
//            myDb.addAppointment("31", "7", "2017", "12:30", "CAR5");
//            myDb.addAppointment("31", "7", "2017", "15:30", "CAR6");
//            myDb.addAppointment("31", "7", "2017", "12:30", "CAR7");
//            myDb.addAppointment("31", "7", "2017", "13:30", "CAR8");
//
//            //Add Customer
//            myDb.addCustomerDetails("PERSON1", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "171-D-12345");
//            myDb.addCustomerDetails("PERSON2", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR2");
//            myDb.addCustomerDetails("PERSON3", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR3");
//            myDb.addCustomerDetails("PERSON4", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR4");
//            myDb.addCustomerDetails("PERSON3", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR5");
//            myDb.addCustomerDetails("PERSON4", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR6");
//            myDb.addCustomerDetails("PERSON3", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR7");
//            myDb.addCustomerDetails("PERSON4", "LASTNAME", "PERSON@EMAIL.COM", "0834579164", "ADDRESS", "CAR8");
//
//            //car 1
//            myDb.addTestedParts("171-D-12345","LAMP","PASS","No problems");
//            myDb.addTestedParts("CAR1","TYRES","PASS","No problems");
//            myDb.addTestedParts("CAR1","WINDOW","PASS","No problems");
//            myDb.addTestedParts("CAR1","EXHAUST","PASS","No problems");
//            myDb.addTestedParts("CAR1","SEATBELTS","PASS","No problems");
//
//            //car 2
//            myDb.addTestedParts("171-D-12345","LAMP","PASS","No problems");
//            myDb.addTestedParts("CAR2","TYRES","PASS","No problems");
//            myDb.addTestedParts("CAR2","WINDOW","PASS","No problems");
//            myDb.addTestedParts("CAR2","EXHAUST","PASS","No problems");
//            myDb.addTestedParts("CAR2","SEATBELTS","PASS","No problems");

            SharedPreferences.Editor editor = populateDb.edit();
            editor.putBoolean("firstRun", false);
            editor.commit();



        }



    }
}
