package com.example.lennard.nctmanagementsystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by lennard on 21/08/2017.
 */


public class MechanicActivity extends AppCompatActivity {

    int no_of_parts;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.untested_layout);

        scheduleTest();
        logout();

    }

    void logout(){
        TextView logout_btn = (TextView)findViewById(R.id.tV_logout);
        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MechanicActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    void scheduleTest() {

        //get current date and time
        Calendar a = Calendar.getInstance();

        int day = a.get(Calendar.DAY_OF_MONTH);
        int month = a.get(Calendar.MONTH);
        int year = a.get(Calendar.YEAR);

        String s_day = Integer.toString(day);
        String s_month = Integer.toString(month);
        String s_year = Integer.toString(year);

        String date = s_day + " " + s_month + " " + s_year;

        TextView current_date = (TextView) findViewById(R.id.tV_current_date);
        current_date.setText("Date - "+ date);

        //DISPLAY ALL UNTESTED CARS
        final DatabaseHelper db = new DatabaseHelper(this);
        Cursor c = db.untestedCars(date);
        String[] from = new String[]{DatabaseHelper.VEHICLE_PLATE_NUMBER_COL, DatabaseHelper.VEHICLE_MODEL_COL, DatabaseHelper.VEHICLE_MAKE_COL, DatabaseHelper.VEHICLE_MILEAGE_COL, DatabaseHelper.VEHICLE_COLOR_COL, DatabaseHelper.VEHICLE_YEAR_COL};
        int[] to = new int[]{R.id.tV_tested_plate_number, R.id.tV_tested_make, R.id.tV_tested_make, R.id.tV_tested_mileage, R.id.tV_tested_color, R.id.tV_untested_year};
        SimpleCursorAdapter untestedAdapter;
        untestedAdapter = new SimpleCursorAdapter(this, R.layout.untested_cars, c, from, to, 0);
        ListView untestedList = (ListView) findViewById(R.id.lV_untested_vehicle);
        untestedList.setAdapter(untestedAdapter);
        untestedList.setTextFilterEnabled(true);

        //DISPLAY UNTESTED PARTS
        untestedList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long arg3) {

                setContentView(R.layout.testing_layout);

                final TextView end_test_btn = (TextView)findViewById(R.id.tV_end_test_btn);
                TextView tV_plateNumber = arg1.findViewById(R.id.tV_tested_plate_number);
                final String plateNumber = tV_plateNumber.getText().toString();

                //Display the chosen plate number
                TextView tV_testing_plate_number = (TextView)findViewById(R.id.tV_testing_plate_number);
                tV_testing_plate_number.setText("Plate Number - "+ plateNumber);

                //Button to end the test
                end_test_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //check if all parts are tested
                        if(no_of_parts > 0){

                            Toast.makeText(getApplicationContext(), "Testing Incomplete", Toast.LENGTH_SHORT).show();


                        }else{
                            Toast.makeText(getApplicationContext(), "Testing Complete", Toast.LENGTH_SHORT).show();

                            //update vehicle status
                            db.updateVehicleStatus(plateNumber,"TESTED");

                            //delete the appointment since it's finished testing
                            db.delete_appointment_schedule(plateNumber);

                            //add the mechanics name to the car he/she performed.
                            SharedPreferences mPrefs = getSharedPreferences("VALUE",0);
                            String mechanic_username = mPrefs.getString("username", "");
                            db.addMechanicName(plateNumber,mechanic_username);

                            Intent intent = new Intent(MechanicActivity.this,MechanicActivity.class);
                            startActivity(intent);
                        }
                    }

                });

                //Display Part List
                String[] vehicleParts;
                vehicleParts = getResources().getStringArray(R.array.vehicleParts);
                final ListView lv_vehicleParts = (ListView) findViewById(R.id.lV_part_list);

                final ArrayList<String> list = new ArrayList<String>();
                for (int i = 0; i < vehicleParts.length; ++i) {
                    list.add(vehicleParts[i]);
                }

                final ArrayAdapter partsAdapter = new ArrayAdapter<String>(getApplicationContext(),
                        R.layout.part_layout, R.id.tV_part_title,
                        list);

                lv_vehicleParts.setAdapter(partsAdapter);

                lv_vehicleParts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> arg0, View arg1,
                                            final int position, long arg3) {

                        TextView tv_part_title = arg1.findViewById(R.id.tV_part_title);
                        final String part_title = tv_part_title.getText().toString();

                        //inflate the part lists
                        AlertDialog.Builder builder = new AlertDialog.Builder(MechanicActivity.this);
                        LayoutInflater inflater = MechanicActivity.this.getLayoutInflater();
                        View layout = inflater.inflate(R.layout.insert_result_layout, null);
                        builder.setView(layout);

                        final Spinner result_spinner = layout.findViewById(R.id.test_result_spinner);
                        ArrayAdapter<CharSequence> result_adapter = ArrayAdapter.createFromResource(MechanicActivity.this,
                                R.array.result, android.R.layout.simple_spinner_item);
                        result_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        result_spinner.setAdapter(result_adapter);

                        TextView partNameTitle = layout.findViewById(R.id.tV_result_part_name);
                        partNameTitle.setText(part_title);

                        final EditText result_details = layout.findViewById(R.id.eT_test_result_detail);
                        TextView confirm_btn = layout.findViewById(R.id.tV_confirm_button);
                        TextView close_btn = layout.findViewById(R.id.tV_close_button);

                        final AlertDialog dialog = builder.create();

                        confirm_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                //Insert Results
                                String partName = part_title;
                                String testResult = result_spinner.getSelectedItem().toString();
                                String details = result_details.getText().toString();

                                //Insert into Database.
                                DatabaseHelper db = new DatabaseHelper(getApplicationContext());
                                db.addTestedParts(plateNumber, partName, testResult, details);

                                //remove the item after testing
                                list.remove(position);
                                partsAdapter.notifyDataSetChanged();
                                no_of_parts = list.size();
                                dialog.dismiss();
                            }
                        });

                        close_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        dialog.show();

                    }
                });
            }
        });
    }

    //if back is pressed go to the same main layout content
    public void onBackPressed(){
        Intent intent = new Intent(MechanicActivity.this,MechanicActivity.class);
        startActivity(intent);
    }


}
