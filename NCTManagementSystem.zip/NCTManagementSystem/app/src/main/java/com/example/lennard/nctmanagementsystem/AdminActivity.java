package com.example.lennard.nctmanagementsystem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by lennard on 21/08/2017.
 */

public class AdminActivity extends AppCompatActivity{

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.admin_panel_layout);

        navigation();

    }


    private void navigation(){

        ImageView create_appointment = (ImageView)findViewById(R.id.iV_scheduled_tests);
        ImageView view_appointment = (ImageView)findViewById(R.id.iV_view_appointment);
        ImageView view_results = (ImageView)findViewById(R.id.iV_view_result);
        ImageView view_users = (ImageView)findViewById(R.id.iV_view_users);
        TextView logout_btn = (TextView)findViewById(R.id.tV_logout);

        create_appointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminActivity.this,CreateAppointmentActivity.class);
                startActivity(intent);
            }
        });

        view_appointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminActivity.this,ViewAppointmentActivity.class);
                startActivity(intent);
            }
        });

        view_results.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminActivity.this,ViewResultActivity.class);
                startActivity(intent);
            }
        });

        view_users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminActivity.this,NewUserActivity.class);
                startActivity(intent);
            }
        });

        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }


}
